import 'dart:ui';

const Color titleTextColor = Color(0xff00602B);

const Color alumniListBackColor = Color(0xffE8F8EF);

const Color drawerBackground_1 = Color(0xff063d21);
const Color drawerBackground_2 = Color(0xff0c602d);

const Color drawerText = Color(0xffFFFFFF);
