

import 'package:get/get.dart';

String BASE_URL = 'http://austtaa.com/server/public/api/';

// String BASE_URL = 'http://172.31.120.58:80/api/';

 // String IMAGE_HEADER = 'http://172.31.120.58:80/images/';

String IMAGE_HEADER = 'http://austtaa.com/public/';

