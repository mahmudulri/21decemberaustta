class ChipModel {
 late  final String id , title;

 ChipModel(String id , String title) {
   this.id = id;
   this.title = title;
 }



}