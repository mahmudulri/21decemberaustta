package com.pakizatvl.austtaa.aust_textile_alumni;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
